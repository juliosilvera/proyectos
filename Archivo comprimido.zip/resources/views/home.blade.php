@extends('app')

@section('content')
<h1>Home</h1>
@stop

@section('footer')

@stop