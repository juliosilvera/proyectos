<footer class="footer">
      <div class="container">
        <p class="text-muted">Todos los derechos reservados &copy; Go Trade 2015</p>
      </div>
</footer>