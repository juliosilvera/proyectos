    <div class="jumbotron">
      <div class="container">
        <div class="divNameHeader">
                <h3>{{ $datos['proyecto'] }}</h3>
        </div>
        <div class="divLogoHeader">
                <img src="/img/logo_white.png" class="logo_header">
        </div>
      </div>
    </div>